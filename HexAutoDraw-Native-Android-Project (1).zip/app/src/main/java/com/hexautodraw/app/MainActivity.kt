package com.hexautodraw.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hexautodraw.app.model.*
import com.hexautodraw.app.processing.ImageProcessor
import com.hexautodraw.app.service.AutoDrawAccessibilityService
import com.hexautodraw.app.service.FloatingOverlayService
import com.hexautodraw.app.state.SessionRecoveryManager
import com.hexautodraw.app.ui.*
import com.hexautodraw.app.ui.theme.HexAutoDrawTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _selectedImageUri = MutableStateFlow<Uri?>(null)
    val selectedImageUri: StateFlow<Uri?> = _selectedImageUri.asStateFlow()

    private val _targetBounds = MutableStateFlow<RectBounds?>(null)
    val targetBounds: StateFlow<RectBounds?> = _targetBounds.asStateFlow()

    private val _drawingSettings = MutableStateFlow(DrawingSettings())
    val drawingSettings: StateFlow<DrawingSettings> = _drawingSettings.asStateFlow()

    private val _processedStrokes = MutableStateFlow<List<Stroke>>(emptyList())
    val processedStrokes: StateFlow<List<Stroke>> = _processedStrokes.asStateFlow()

    fun setSelectedImage(uri: Uri) { _selectedImageUri.value = uri }
    fun setTargetBounds(bounds: RectBounds) { _targetBounds.value = bounds }
    fun updateSettings(settings: DrawingSettings) { _drawingSettings.value = settings }

    fun processImage(context: Context, onComplete: () -> Unit) {
        val uri = _selectedImageUri.value ?: return
        viewModelScope.launch {
            val bitmapResult = ImageProcessor.loadAndScaleBitmap(context, uri)
            bitmapResult.onSuccess { bitmap ->
                val bounds = _targetBounds.value ?: run {
                    val dm = context.resources.displayMetrics
                    val defaultSize = (dm.widthPixels * 0.85f).toInt()
                    RectBounds(
                        (dm.widthPixels - defaultSize) / 2,
                        (dm.heightPixels - defaultSize) / 3,
                        (dm.widthPixels + defaultSize) / 2,
                        ((dm.heightPixels - defaultSize) / 3) + defaultSize
                    )
                }
                val strokes = ImageProcessor.processImageToStrokes(bitmap, bounds, _drawingSettings.value)
                _processedStrokes.value = strokes
                onComplete()
            }.onFailure { err ->
                Toast.makeText(context, "Failed to load image: ${err.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private lateinit var recoveryManager: SessionRecoveryManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        recoveryManager = SessionRecoveryManager(applicationContext)

        setContent {
            HexAutoDrawTheme {
                val selectedImageUri by viewModel.selectedImageUri.collectAsState()
                val targetBounds by viewModel.targetBounds.collectAsState()
                val drawingSettings by viewModel.drawingSettings.collectAsState()

                val serviceStatus by AutoDrawAccessibilityService.statusFlow.collectAsState()
                val currentStroke by AutoDrawAccessibilityService.currentStrokeFlow.collectAsState()
                val totalStrokes by AutoDrawAccessibilityService.totalStrokesFlow.collectAsState()
                val etaSeconds by AutoDrawAccessibilityService.etaSecondsFlow.collectAsState()

                var showPermissionsDialog by remember { mutableStateOf(false) }
                var showCropAreaDialog by remember { mutableStateOf(false) }
                var showSettingsDialog by remember { mutableStateOf(false) }
                var showRecoveryDialog by remember { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    if (recoveryManager.hasRecoverableSession()) showRecoveryDialog = true
                }

                LaunchedEffect(FloatingOverlayService.confirmedCanvasBounds) {
                    FloatingOverlayService.confirmedCanvasBounds?.let { bounds ->
                        viewModel.setTargetBounds(bounds)
                        FloatingOverlayService.confirmedCanvasBounds = null
                        Toast.makeText(this@MainActivity, "Calibrated: ${bounds.width}x${bounds.height}px", Toast.LENGTH_SHORT).show()
                    }
                }

                val hasOverlayPermission = Settings.canDrawOverlays(this)
                val hasAccessibilityPermission = isAccessibilityServiceEnabled()
                val currentProgressPercent = if (totalStrokes > 0) ((currentStroke.toFloat() / totalStrokes) * 100).toInt().coerceIn(0, 100) else 0

                HomeScreen(
                    selectedImageUri = selectedImageUri,
                    currentStatus = serviceStatus,
                    currentProgressPercent = currentProgressPercent,
                    currentStrokeIndex = currentStroke,
                    totalStrokes = totalStrokes,
                    etaSeconds = etaSeconds,
                    targetBounds = targetBounds,
                    drawingSettings = drawingSettings,
                    isAccessibilityEnabled = hasAccessibilityPermission,
                    isOverlayPermissionGranted = hasOverlayPermission,
                    onSelectImage = { uri -> viewModel.setSelectedImage(uri) },
                    onOpenCropArea = { showCropAreaDialog = true },
                    onOpenSettings = { showSettingsDialog = true },
                    onOpenPermissions = { showPermissionsDialog = true },
                    onStartDrawing = {
                        if (!isAccessibilityServiceEnabled()) {
                            showPermissionsDialog = true
                            return@HomeScreen
                        }
                        viewModel.processImage(this) {
                            val strokes = viewModel.processedStrokes.value
                            if (strokes.isNotEmpty()) {
                                if (Settings.canDrawOverlays(this)) {
                                    val hudIntent = Intent(this, FloatingOverlayService::class.java).apply {
                                        action = FloatingOverlayService.ACTION_SHOW_HUD
                                    }
                                    startService(hudIntent)
                                }
                                AutoDrawAccessibilityService.instance?.startDrawing(strokes, drawingSettings)
                                Toast.makeText(this, "Drawing started! Switch to WePlay.", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    onPauseDrawing = { AutoDrawAccessibilityService.instance?.pauseDrawing() },
                    onResumeDrawing = { AutoDrawAccessibilityService.instance?.resumeDrawing() },
                    onStopDrawing = {
                        AutoDrawAccessibilityService.instance?.stopDrawing()
                        stopService(Intent(this, FloatingOverlayService::class.java))
                    }
                )

                if (showPermissionsDialog) PermissionExplanationDialog(this) { showPermissionsDialog = false }
                if (showCropAreaDialog) CanvasAreaSelectionDialog(this, targetBounds, { showCropAreaDialog = false }) {
                    showCropAreaDialog = false
                    startService(Intent(this, FloatingOverlayService::class.java).apply { action = FloatingOverlayService.ACTION_SHOW_SELECTOR })
                }
                if (showSettingsDialog) DrawingSettingsDialog(drawingSettings, { showSettingsDialog = false }) {
                    viewModel.updateSettings(it)
                    showSettingsDialog = false
                }
                if (showRecoveryDialog) SessionRecoveryDialog(recoveryManager.currentSession.value, {
                    showRecoveryDialog = false
                    val saved = recoveryManager.currentSession.value
                    saved.targetBounds?.let { viewModel.setTargetBounds(it) }
                    saved.imageUriString?.let { viewModel.setSelectedImage(Uri.parse(it)) }
                    viewModel.processImage(this) {
                        AutoDrawAccessibilityService.instance?.startDrawing(
                            viewModel.processedStrokes.value,
                            drawingSettings,
                            saved.currentStrokeIndex,
                            saved.currentPointIndex
                        )
                    }
                }, {
                    recoveryManager.clearSession()
                    showRecoveryDialog = false
                })
            }
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "${packageName}/${AutoDrawAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }
}