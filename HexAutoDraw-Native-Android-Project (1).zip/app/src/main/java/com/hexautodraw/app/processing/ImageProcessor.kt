package com.hexautodraw.app.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.hexautodraw.app.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.util.UUID
import kotlin.math.*

object ImageProcessor {

    private const val MAX_PROCESSING_DIMENSION = 640

    suspend fun loadAndScaleBitmap(context: Context, uri: Uri): Result<Bitmap> = withContext(Dispatchers.IO) {
        try {
            var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            val srcWidth = options.outWidth
            val srcHeight = options.outHeight
            if (srcWidth <= 0 || srcHeight <= 0) {
                return@withContext Result.failure(IllegalArgumentException("Invalid image dimensions"))
            }

            var inSampleSize = 1
            if (srcHeight > MAX_PROCESSING_DIMENSION || srcWidth > MAX_PROCESSING_DIMENSION) {
                val halfHeight = srcHeight / 2
                val halfWidth = srcWidth / 2
                while ((halfHeight / inSampleSize) >= MAX_PROCESSING_DIMENSION &&
                    (halfWidth / inSampleSize) >= MAX_PROCESSING_DIMENSION) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            inputStream = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream?.close()

            if (bitmap != null) Result.success(bitmap)
            else Result.failure(IllegalStateException("Failed to decode image bitmap"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun processImageToStrokes(
        bitmap: Bitmap,
        targetBounds: RectBounds,
        settings: DrawingSettings
    ): List<Stroke> = withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height

        val gray = IntArray(width * height)
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            gray[i] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
        }

        val threshold = when (settings.mode) {
            DrawingMode.OUTLINE -> 85
            DrawingMode.DETAILED -> 48
            DrawingMode.SIMPLE -> 115
        }

        val edges = BooleanArray(width * height)
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val gx = (
                    -1 * gray[(y - 1) * width + (x - 1)] + 1 * gray[(y - 1) * width + (x + 1)] +
                    -2 * gray[y * width + (x - 1)] + 2 * gray[y * width + (x + 1)] +
                    -1 * gray[(y + 1) * width + (x - 1)] + 1 * gray[(y + 1) * width + (x + 1)]
                )
                val gy = (
                    -1 * gray[(y - 1) * width + (x - 1)] - 2 * gray[(y - 1) * width + x] - 1 * gray[(y - 1) * width + (x + 1)] +
                    1 * gray[(y + 1) * width + (x - 1)] + 2 * gray[(y + 1) * width + x] + 1 * gray[(y + 1) * width + (x + 1)]
                )
                val magnitude = hypot(gx.toDouble(), gy.toDouble()).toInt()
                if (magnitude > threshold) {
                    edges[y * width + x] = true
                }
            }
        }

        val visited = BooleanArray(width * height)
        val rawStrokes = mutableListOf<List<PointF>>()
        val dx = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)
        val dy = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)
        val minPoints = when (settings.mode) {
            DrawingMode.OUTLINE -> 5
            DrawingMode.DETAILED -> 3
            DrawingMode.SIMPLE -> 8
        }

        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val idx = y * width + x
                if (edges[idx] && !visited[idx]) {
                    val points = mutableListOf<PointF>()
                    var currX = x
                    var currY = y

                    while (true) {
                        val cIdx = currY * width + currX
                        visited[cIdx] = true
                        points.add(PointF(currX.toFloat(), currY.toFloat()))

                        var nextX = -1
                        var nextY = -1
                        for (d in 0 until 8) {
                            val nx = currX + dx[d]
                            val ny = currY + dy[d]
                            if (nx in 0 until width && ny in 0 until height) {
                                val nIdx = ny * width + nx
                                if (edges[nIdx] && !visited[nIdx]) {
                                    nextX = nx
                                    nextY = ny
                                    break
                                }
                            }
                        }

                        if (nextX != -1 && nextY != -1) {
                            currX = nextX
                            currY = nextY
                        } else break
                    }

                    if (points.size >= minPoints) {
                        rawStrokes.add(points)
                    }
                }
            }
        }

        val scaleX = targetBounds.width.toFloat() / width
        val scaleY = targetBounds.height.toFloat() / height
        val scale: Float
        val offsetX: Float
        val offsetY: Float

        if (settings.preserveAspectRatio) {
            scale = min(scaleX, scaleY)
            val fittedW = width * scale
            val fittedH = height * scale
            offsetX = targetBounds.left + (targetBounds.width - fittedW) / 2f
            offsetY = targetBounds.top + (targetBounds.height - fittedH) / 2f
        } else {
            scale = 1f
            offsetX = targetBounds.left.toFloat()
            offsetY = targetBounds.top.toFloat()
        }

        val processedStrokes = mutableListOf<Stroke>()
        for (raw in rawStrokes) {
            val simplified = simplifyPointsRDP(raw, settings.simplificationTolerance)
            if (simplified.size < 2) continue

            val mappedPoints = simplified.map { p ->
                val px = if (settings.preserveAspectRatio) offsetX + p.x * scale else targetBounds.left + p.x * scaleX
                val py = if (settings.preserveAspectRatio) offsetY + p.y * scale else targetBounds.top + p.y * scaleY
                PointF(
                    x = px.coerceIn(targetBounds.left.toFloat(), targetBounds.right.toFloat()),
                    y = py.coerceIn(targetBounds.top.toFloat(), targetBounds.bottom.toFloat())
                )
            }

            var length = 0f
            for (i in 0 until mappedPoints.size - 1) {
                length += hypot(mappedPoints[i + 1].x - mappedPoints[i].x, mappedPoints[i + 1].y - mappedPoints[i].y)
            }

            processedStrokes.add(Stroke(UUID.randomUUID().toString(), mappedPoints, length))
        }

        optimizeStrokeOrder(processedStrokes)
    }

    private fun simplifyPointsRDP(points: List<PointF>, epsilon: Float): List<PointF> {
        if (points.size <= 2) return points
        var maxDistance = 0f
        var index = 0
        val start = points.first()
        val end = points.last()

        for (i in 1 until points.size - 1) {
            val dist = perpendicularDistance(points[i], start, end)
            if (dist > maxDistance) {
                maxDistance = dist
                index = i
            }
        }

        return if (maxDistance > epsilon) {
            val left = simplifyPointsRDP(points.subList(0, index + 1), epsilon)
            val right = simplifyPointsRDP(points.subList(index, points.size), epsilon)
            left.dropLast(1) + right
        } else {
            listOf(start, end)
        }
    }

    private fun perpendicularDistance(p: PointF, p1: PointF, p2: PointF): Float {
        val dx = p2.x - p1.x
        val dy = p2.y - p1.y
        val lenSq = dx * dx + dy * dy
        if (lenSq == 0f) return sqrt((p.x - p1.x) * (p.x - p1.x) + (p.y - p1.y) * (p.y - p1.y))
        val numerator = abs(dy * p.x - dx * p.y + p2.x * p1.y - p2.y * p1.x)
        return (numerator / sqrt(lenSq))
    }

    private fun optimizeStrokeOrder(strokes: MutableList<Stroke>): List<Stroke> {
        if (strokes.size <= 1) return strokes
        val ordered = mutableListOf<Stroke>()
        val pool = strokes.toMutableList()
        var current = pool.removeAt(0)
        ordered.add(current)

        while (pool.isNotEmpty()) {
            val lastPoint = current.points.last()
            var closestIdx = 0
            var closestDist = Float.MAX_VALUE
            for (i in pool.indices) {
                val candidateStart = pool[i].points.first()
                val dist = hypot(candidateStart.x - lastPoint.x, candidateStart.y - lastPoint.y)
                if (dist < closestDist) {
                    closestDist = dist
                    closestIdx = i
                }
            }
            current = pool.removeAt(closestIdx)
            ordered.add(current)
        }
        return ordered
    }
}