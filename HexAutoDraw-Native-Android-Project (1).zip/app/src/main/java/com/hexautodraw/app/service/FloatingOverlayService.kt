package com.hexautodraw.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.hexautodraw.app.MainActivity
import com.hexautodraw.app.model.DrawingStatus
import com.hexautodraw.app.model.RectBounds
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class FloatingOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager

    private var areaSelectionView: View? = null
    private var floatingHudView: View? = null

    private var rectX = 100
    private var rectY = 300
    private var rectWidth = 600
    private var rectHeight = 600

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action ?: ACTION_SHOW_SELECTOR) {
            ACTION_SHOW_SELECTOR -> showCanvasAreaSelector()
            ACTION_SHOW_HUD -> showFloatingHud()
            ACTION_CLOSE_ALL -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAreaSelector()
        removeFloatingHud()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showCanvasAreaSelector() {
        if (areaSelectionView != null) return

        val displayMetrics = resources.displayMetrics
        val screenW = displayMetrics.widthPixels
        val screenH = displayMetrics.heightPixels

        rectWidth = (screenW * 0.85f).toInt()
        rectHeight = (screenW * 0.85f).toInt()
        rectX = (screenW - rectWidth) / 2
        rectY = (screenH - rectHeight) / 3

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#44000000"))

        val box = FrameLayout(this)
        val boxDrawable = GradientDrawable().apply {
            setStroke(6, Color.parseColor("#06B6D4"))
            setColor(Color.parseColor("#1A06B6D4"))
            cornerRadius = 8f
        }
        box.background = boxDrawable

        val boxParams = FrameLayout.LayoutParams(rectWidth, rectHeight).apply {
            leftMargin = rectX
            topMargin = rectY
        }
        root.addView(box, boxParams)

        val infoPill = TextView(this).apply {
            text = "Canvas Area: ${rectWidth} x ${rectHeight} px\nDrag box to align with WePlay canvas"
            setTextColor(Color.WHITE)
            textSize = 13f
            setBackgroundColor(Color.parseColor("#DD090D16"))
            setPadding(24, 16, 24, 16)
            gravity = Gravity.CENTER
        }
        val infoParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = 120
        }
        root.addView(infoPill, infoParams)

        val buttonsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val btnCancel = Button(this).apply {
            text = "Cancel"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#EF4444"))
            setOnClickListener {
                removeAreaSelector()
                stopSelf()
            }
        }
        val btnConfirm = Button(this).apply {
            text = "Confirm Canvas Area"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#06B6D4"))
            setOnClickListener {
                confirmedCanvasBounds = RectBounds(rectX, rectY, rectX + rectWidth, rectY + rectHeight)
                removeAreaSelector()
                val mainIntent = Intent(this@FloatingOverlayService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(mainIntent)
            }
        }

        buttonsBar.addView(btnCancel)
        buttonsBar.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(40, 1) })
        buttonsBar.addView(btnConfirm)

        val barParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = 140
        }
        root.addView(buttonsBar, barParams)

        var lastTouchX = 0f
        var lastTouchY = 0f
        box.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastTouchX
                    val dy = event.rawY - lastTouchY
                    rectX = (rectX + dx.toInt()).coerceIn(0, screenW - rectWidth)
                    rectY = (rectY + dy.toInt()).coerceIn(100, screenH - rectHeight - 100)
                    boxParams.leftMargin = rectX
                    boxParams.topMargin = rectY
                    box.layoutParams = boxParams
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    infoPill.text = "Canvas Area: ${rectWidth} x ${rectHeight} px (X: $rectX, Y: $rectY)\nDrag box to align with WePlay canvas"
                    true
                }
                else -> false
            }
        }

        areaSelectionView = root
        windowManager.addView(root, layoutParams)
    }

    private fun showFloatingHud() {
        if (floatingHudView != null) return

        val hudParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        val hudLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(20, 14, 20, 14)
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#F0090D16"))
                setStroke(3, Color.parseColor("#06B6D4"))
                cornerRadius = 40f
            }
            background = bg
            gravity = Gravity.CENTER_VERTICAL
        }

        val statusText = TextView(this).apply {
            text = "HexDraw: 0%"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(0, 0, 16, 0)
        }
        hudLayout.addView(statusText)

        val btnPauseResume = Button(this).apply {
            text = "Pause"
            textSize = 11f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#06B6D4"))
            setOnClickListener {
                val service = AutoDrawAccessibilityService.instance
                if (service != null) {
                    if (AutoDrawAccessibilityService.statusFlow.value == DrawingStatus.DRAWING) {
                        service.pauseDrawing()
                        text = "Resume"
                    } else if (AutoDrawAccessibilityService.statusFlow.value == DrawingStatus.PAUSED) {
                        service.resumeDrawing()
                        text = "Pause"
                    }
                }
            }
        }
        hudLayout.addView(btnPauseResume)

        val btnStop = Button(this).apply {
            text = "Stop"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#EF4444"))
            setOnClickListener {
                AutoDrawAccessibilityService.instance?.stopDrawing()
                removeFloatingHud()
            }
        }
        hudLayout.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(12, 1) })
        hudLayout.addView(btnStop)

        serviceScope.launch {
            AutoDrawAccessibilityService.currentStrokeFlow.collectLatest { cur ->
                val total = AutoDrawAccessibilityService.totalStrokesFlow.value
                val pct = if (total > 0) ((cur.toFloat() / total) * 100).toInt() else 0
                val status = AutoDrawAccessibilityService.statusFlow.value
                statusText.text = "Hex: $pct% ($status)"
                if (status == DrawingStatus.PAUSED) {
                    btnPauseResume.text = "Resume"
                } else if (status == DrawingStatus.DRAWING) {
                    btnPauseResume.text = "Pause"
                }
            }
        }

        floatingHudView = hudLayout
        windowManager.addView(hudLayout, hudParams)
    }

    private fun removeAreaSelector() {
        areaSelectionView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
            areaSelectionView = null
        }
    }

    private fun removeFloatingHud() {
        floatingHudView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
            floatingHudView = null
        }
    }

    private fun startForegroundNotification() {
        val channelId = "hex_autodraw_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Hex AutoDraw Active Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("Hex AutoDraw Running")
                .setContentText("Overlay active. Tap to return to settings.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(pendingIntent)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Hex AutoDraw Running")
                .setContentText("Overlay active.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(pendingIntent)
                .build()
        }

        startForeground(1001, notification)
    }

    companion object {
        const val ACTION_SHOW_SELECTOR = "com.hexautodraw.SHOW_SELECTOR"
        const val ACTION_SHOW_HUD = "com.hexautodraw.SHOW_HUD"
        const val ACTION_CLOSE_ALL = "com.hexautodraw.CLOSE_ALL"
        var confirmedCanvasBounds: RectBounds? = null
    }
}