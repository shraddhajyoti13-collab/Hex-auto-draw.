package com.hexautodraw.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.hexautodraw.app.model.DrawingSettings
import com.hexautodraw.app.model.DrawingStatus
import com.hexautodraw.app.model.PointF
import com.hexautodraw.app.model.Stroke
import com.hexautodraw.app.state.SessionRecoveryManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

class AutoDrawAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var drawingJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var recoveryManager: SessionRecoveryManager

    private val isDrawingActive = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)

    private var activeStrokes: List<Stroke> = emptyList()
    private var activeSettings: DrawingSettings = DrawingSettings()
    private var currentStrokeIdx = 0
    private var currentBatchIdx = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceActive.value = true
        recoveryManager = SessionRecoveryManager(applicationContext)
        Log.i(TAG, "Hex AutoDraw Accessibility Service Connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service Interrupted by system.")
        pauseDrawing()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopDrawing()
        serviceScope.cancel()
        instance = null
        _isServiceActive.value = false
    }

    fun startDrawing(
        strokes: List<Stroke>,
        settings: DrawingSettings,
        startFromStroke: Int = 0,
        startFromBatch: Int = 0
    ) {
        if (strokes.isEmpty()) {
            _statusFlow.value = DrawingStatus.ERROR
            return
        }

        activeStrokes = strokes
        activeSettings = settings
        currentStrokeIdx = startFromStroke.coerceIn(0, strokes.size - 1)
        currentBatchIdx = startFromBatch

        isDrawingActive.set(true)
        isPaused.set(false)
        _statusFlow.value = DrawingStatus.DRAWING
        _totalStrokesFlow.value = strokes.size

        drawingJob?.cancel()
        drawingJob = serviceScope.launch {
            runDrawingLoop()
        }
    }

    fun pauseDrawing() {
        if (!isDrawingActive.get()) return
        isPaused.set(true)
        isDrawingActive.set(false)
        drawingJob?.cancel()
        _statusFlow.value = DrawingStatus.PAUSED
        persistState()
    }

    fun resumeDrawing() {
        if (activeStrokes.isEmpty()) return
        if (currentStrokeIdx >= activeStrokes.size) {
            _statusFlow.value = DrawingStatus.COMPLETED
            return
        }

        isDrawingActive.set(true)
        isPaused.set(false)
        _statusFlow.value = DrawingStatus.DRAWING

        drawingJob?.cancel()
        drawingJob = serviceScope.launch {
            runDrawingLoop()
        }
    }

    fun stopDrawing() {
        isDrawingActive.set(false)
        isPaused.set(false)
        drawingJob?.cancel()
        _statusFlow.value = DrawingStatus.STOPPED
        persistState()
    }

    private suspend fun runDrawingLoop() {
        val total = activeStrokes.size

        while (currentStrokeIdx < total && isDrawingActive.get() && !isPaused.get()) {
            val stroke = activeStrokes[currentStrokeIdx]
            val batches = splitStrokeIntoBatches(stroke.points, activeSettings.maxBatchSize)

            while (currentBatchIdx < batches.size && isDrawingActive.get() && !isPaused.get()) {
                val batchPoints = batches[currentBatchIdx]
                if (batchPoints.size >= 2) {
                    dispatchStrokeBatch(batchPoints, activeSettings.strokeSpeedMs)
                    delay(activeSettings.strokeSpeedMs + activeSettings.pauseDelayMs)
                }
                currentBatchIdx++
            }

            if (isPaused.get() || !isDrawingActive.get()) break

            currentBatchIdx = 0
            currentStrokeIdx++
            _currentStrokeFlow.value = currentStrokeIdx

            val remainingStrokes = total - currentStrokeIdx
            val msPerStroke = (activeSettings.strokeSpeedMs + activeSettings.pauseDelayMs)
            _etaSecondsFlow.value = ((remainingStrokes * msPerStroke) / 1000).toInt()

            if (currentStrokeIdx % 10 == 0) persistState()
        }

        if (currentStrokeIdx >= total && !isPaused.get()) {
            _statusFlow.value = DrawingStatus.COMPLETED
            isDrawingActive.set(false)
            persistState()
        }
    }

    private fun dispatchStrokeBatch(points: List<PointF>, durationMs: Long): Boolean {
        if (points.size < 2) return false

        val path = Path()
        path.moveTo(points.first().x, points.first().y)
        for (i in 1 until points.size) {
            path.lineTo(points[i].x, points[i].y)
        }

        val strokeDescription = GestureDescription.StrokeDescription(
            path,
            0L,
            durationMs.coerceIn(20L, 200L)
        )

        val gesture = GestureDescription.Builder()
            .addStroke(strokeDescription)
            .build()

        return dispatchGesture(gesture, object : GestureResultCallback() {}, mainHandler)
    }

    private fun splitStrokeIntoBatches(points: List<PointF>, maxBatchSize: Int): List<List<PointF>> {
        if (points.size <= maxBatchSize) return listOf(points)
        val batches = mutableListOf<List<PointF>>()
        var i = 0
        while (i < points.size - 1) {
            val end = (i + maxBatchSize).coerceAtMost(points.size)
            batches.add(points.subList(i, end))
            i = end - 1
        }
        return batches
    }

    private fun persistState() {
        if (::recoveryManager.isInitialized) {
            val current = recoveryManager.currentSession.value
            recoveryManager.saveSession(
                current.copy(
                    totalStrokes = activeStrokes.size,
                    currentStrokeIndex = currentStrokeIdx,
                    currentPointIndex = currentBatchIdx,
                    status = _statusFlow.value,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    companion object {
        private const val TAG = "HexAutoDrawService"

        var instance: AutoDrawAccessibilityService? = null
            private set

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        private val _statusFlow = MutableStateFlow(DrawingStatus.READY)
        val statusFlow: StateFlow<DrawingStatus> = _statusFlow.asStateFlow()

        private val _currentStrokeFlow = MutableStateFlow(0)
        val currentStrokeFlow: StateFlow<Int> = _currentStrokeFlow.asStateFlow()

        private val _totalStrokesFlow = MutableStateFlow(0)
        val totalStrokesFlow: StateFlow<Int> = _totalStrokesFlow.asStateFlow()

        private val _etaSecondsFlow = MutableStateFlow(0)
        val etaSecondsFlow: StateFlow<Int> = _etaSecondsFlow.asStateFlow()
    }
}